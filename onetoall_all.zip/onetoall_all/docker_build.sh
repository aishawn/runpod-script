docker build -t  aishawn/onetoall:v1.3 .
docker push aishawn/onetoall:v1.3